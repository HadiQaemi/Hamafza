<style>
    .content
    {
        min-height: 300px;
    }
</style>
