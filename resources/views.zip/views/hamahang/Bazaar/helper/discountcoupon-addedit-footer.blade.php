<div class="row">
    <span>
        <button type="button" class="btn btn-primary" id="submit" onclick="do_submit()">
            <i ></i> <span>{!! $add ? 'افزودن کد' : 'ویرایش کد' !!}</span>
        </button>
    </span>
</div>
