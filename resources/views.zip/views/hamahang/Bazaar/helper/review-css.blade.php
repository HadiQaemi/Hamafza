<style>
    .content
    {
        min-height: 300px;
    }
    .h-refresh
    {
        background-color: #E3F3FC;
    }
    .h-refresh .fa-refresh
    {
        color: #53ADE7;
        cursor: pointer;
        font-size: 17px;
    }
    .table_inner.table,
    .table_inner.table > thead > tr > th,
    .table_inner.table > tbody > tr > th,
    .table_inner.table > tfoot > tr > th,
    .table_inner.table > thead > tr > td,
    .table_inner.table > tbody > tr > td,
    .table_inner.table > tfoot > tr > td
    {
        border: none;
        color: #666666;
        vertical-align: middle;
    }
    .table,
    .table-bordered > thead > tr > th,
    .table-bordered > tbody > tr > th,
    .table-bordered > tfoot > tr > th,
    .table-bordered > thead > tr > td,
    .table-bordered > tbody > tr > td,
    .table-bordered > tfoot > tr > td
    {
        border: 1px solid #F0F1F2;
        color: #666666;
        vertical-align: middle;
    }
    table.table-bordered thead tr td
    {
        padding-top: 10px;
    }
    .h-refresh
    {
        background-color: #E3F3FC;
    }
    .h-refresh .fa-refresh
    {
        color: #53ADE7;
        cursor: pointer;
        font-size: 17px;
    }
    .green
    {
        color: #5DAF50;
    }
</style>
