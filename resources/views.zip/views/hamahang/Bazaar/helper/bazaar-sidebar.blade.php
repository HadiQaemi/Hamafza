<div class="small col-md-12" style="height: 589px;">
    <div class="panel-heading panel-heading-darkblue h-dropdown-h" id="dropdown-1">عنوان</div>
    <div class="panel panel-light panel-list padding-remov h-dropdown-list" style="font-size: 9pt;"  id="dropdown-1-list">
        <div>سبد خرید من</div>
        <div>فروش من</div>
        <div>حساب من</div>
        <div>همه</div>
    </div>

    <div class="panel-heading panel-heading-darkblue h-dropdown-h" id="dropdown-2">سابقه</div>
    <div class="panel panel-light panel-list padding-remov h-dropdown-list" style="font-size: 9pt;"  id="dropdown-2-list">
    </div>

    <div class="panel-heading panel-heading-darkblue h-dropdown-h" id="dropdown-3">جدول بدهی، بستانکاری</div>
    <div class="panel panel-light panel-list padding-remov h-dropdown-list" style="font-size: 9pt;"  id="dropdown-3-list">
    </div>

    <div class="panel-heading panel-heading-darkblue h-dropdown-h" id="dropdown-4">خرید حساب</div>
    <div class="panel panel-light panel-list padding-remov h-dropdown-list" style="font-size: 9pt;"  id="dropdown-4-list">
    </div>

    <div class="panel-heading panel-heading-darkblue h-dropdown-h" id="dropdown-5">فایل ها</div>
    <div class="panel panel-light panel-list padding-remov h-dropdown-list" style="font-size: 9pt;"  id="dropdown-5-list">
    </div>

    <div class="panel-heading panel-heading-darkblue h-dropdown-h" id="dropdown-6">یادداشت ها</div>
    <div class="panel panel-light panel-list padding-remov h-dropdown-list" style="font-size: 9pt;"  id="dropdown-6-list">
    </div>

    <div class="panel-heading panel-heading-darkblue h-dropdown-h" id="dropdown-7">فرم ها</div>
    <div class="panel panel-light panel-list padding-remov h-dropdown-list" style="font-size: 9pt;"  id="dropdown-7-list">
    </div>

    <div class="panel-heading panel-heading-darkblue h-dropdown-h" id="dropdown-8">حساب کاربری</div>
    <div class="panel panel-light panel-list padding-remov h-dropdown-list" style="font-size: 9pt;"  id="dropdown-8-list">
    </div>
</div>
