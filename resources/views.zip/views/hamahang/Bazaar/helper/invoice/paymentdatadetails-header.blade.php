@include('hamahang.Bazaar.helper.invoice.paymentdatadetails-css')
@include('hamahang.Bazaar.helper.invoice.paymentdatadetails-js')
{!! trans('bazaar.invoice.paymentdata.details') !!}