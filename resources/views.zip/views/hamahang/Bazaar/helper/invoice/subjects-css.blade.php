<style>
    #invoice_status_table tr td
    {
        vertical-align: middle;
    }
    #invoice_status_table tr td img
    {
        border-radius: 10px 0;
    }
</style>