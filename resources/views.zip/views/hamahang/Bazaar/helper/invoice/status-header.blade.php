@include('hamahang.Bazaar.helper.invoice.status-css')
@include('hamahang.Bazaar.helper.invoice.status-js')
{!! trans('bazaar.invoice.operations_status') !!}