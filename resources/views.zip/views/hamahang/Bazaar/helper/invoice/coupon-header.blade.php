@include('hamahang.Bazaar.helper.invoice.coupon-css')
@include('hamahang.Bazaar.helper.invoice.coupon-js')
{!! trans('bazaar.invoice.operations_coupon') !!}