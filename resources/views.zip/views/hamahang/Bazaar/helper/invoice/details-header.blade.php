@include('hamahang.Bazaar.helper.invoice.details-css')
@include('hamahang.Bazaar.helper.invoice.details-js')
{!! trans('bazaar.invoice.operations_details') !!}