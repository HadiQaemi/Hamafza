<script>
    $(document).ready(function()
    {

    });
</script>