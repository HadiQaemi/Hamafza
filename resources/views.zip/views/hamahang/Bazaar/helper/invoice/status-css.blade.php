<style>
    #invoice_status_table th:first-child,
    #invoice_status_table td:first-child
    {
        text-align: right;
    }
    #invoice_status_table th,
    #invoice_status_table td
    {
        text-align: center;
    }
</style>