@include('hamahang.Bazaar.helper.invoice.paymentdata-css')
@include('hamahang.Bazaar.helper.invoice.paymentdata-js')
{!! trans('bazaar.invoice.operations_paymentdata') !!}