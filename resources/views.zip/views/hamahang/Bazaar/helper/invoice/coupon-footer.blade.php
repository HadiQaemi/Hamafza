<div class="row">
    <span>
        <button type="button" class="btn btn-primary" id="submit" onclick="$(this).parent().parent().parent().parent().find('.jsglyph-close').click();">
            <i class="fa fa-close"></i>&nbsp;{!! trans('bazaar.close') !!}
        </button>
    </span>
</div>
