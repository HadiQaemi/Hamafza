@include('hamahang.Bazaar.helper.invoice.subjects-css')
@include('hamahang.Bazaar.helper.invoice.subjects-js')
{!! trans('bazaar.invoice.operations_subjects') !!}