<script>
    $(document).ready(function()
    {
        e_jspanel = $('.table_coupon').parent().parent();
        get_left = e_jspanel.position().left;
        get_width = e_jspanel.width();
        get_top = e_jspanel.position().top;
        get_height = e_jspanel.height();
        e_jspanel.find('.jsPanel-content').animate({height: get_height - 295});
        e_jspanel.animate({left: get_left + 200, width: get_width - 400, top: get_top + 100, height: get_height - 200}, function()
        {
            $('.table_coupon').fadeIn();
        });
    });
</script>