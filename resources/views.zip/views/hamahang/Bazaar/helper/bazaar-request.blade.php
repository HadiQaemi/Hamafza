<script>
    window.location = '{!! $url_cart !!}';
</script>