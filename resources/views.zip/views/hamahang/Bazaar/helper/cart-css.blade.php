<style>
    .table_inner.table,
    .table_inner.table > thead > tr > th,
    .table_inner.table > tbody > tr > th,
    .table_inner.table > tfoot > tr > th,
    .table_inner.table > thead > tr > td,
    .table_inner.table > tbody > tr > td,
    .table_inner.table > tfoot > tr > td
    {
        border: none;
        color: #666666;
        vertical-align: middle;
    }
    .content
    {
        min-height: 300px;
    }
</style>
