<style>
    .content
    {
        min-height: 300px;
    }
    .progress-done
    {
        padding-top: 6px;
    }
</style>
