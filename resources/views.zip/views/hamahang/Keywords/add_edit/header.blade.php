@include('hamahang.Keywords.add_edit.css')
@include('hamahang.Keywords.add_edit.js')
{!! $is_edit ? 'ویرایش کلیدواژه' : 'کلیدواژه جدید' !!}

