<div>
    <button class="btn btn-info pull-left" onclick="$(this).parent().parent().parent().find('.jsglyph-close').click();">بستن</button>
</div>
