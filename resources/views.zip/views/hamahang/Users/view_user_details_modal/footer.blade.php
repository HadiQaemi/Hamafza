<span class="FloatLeft">
    <div id="div_bas_footer">
    <input type="button" value="تایید" class="btn btn-primary btn_edit_user_detail">
    </div>
</span>