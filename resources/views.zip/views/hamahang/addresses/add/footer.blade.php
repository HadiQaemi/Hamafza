<div class="row">
    <span>
        <button type="button" class="btn btn-primary" id="submit" onclick="do_submit(this)" value="ثبت">
            <i ></i> <span>ثبت</span>
        </button>
    </span>
</div>
