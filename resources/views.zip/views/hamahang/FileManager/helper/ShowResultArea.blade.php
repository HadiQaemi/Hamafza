<!-- _Result______ File Manager ______Result_ -->
<div class="row-fluid">
	<div class="col-lg-12">
		<div id="HFM_ResultUpload_{{$section}}" class="row-fluid grey">
			<div id="HFM_ResultsArea_{{$section}}">
			</div>
		</div>
	</div>
	<div class="clearfix"></div>
	{{--<div class="hr hr-double dotted"></div>--}}
</div>
<div class="clearfix"></div>