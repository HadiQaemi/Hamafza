<div class="form-group" style="padding-left: 60px;">
    <label class="radio-inline"><input type="radio" value="1" name="radio_check" checked>ایجاد</label>
    <label class="radio-inline"><input type="radio" value="2" name="radio_check">ایجاد و ویرایش</label>
</div>
<div class="form-group" style="width: 230px;direction: ltr;">
    <input type="submit" style="display:none"  id="taed_edit" value="تایید" class="btn btn-primary "/>
    <input type="submit"  id="taed_add" value="تایید" class="btn btn-primary "/>
    <input type="submit"  id="taed_add_page" value="تایید و ایجاد صفحه جدید" class="btn btn-primary "/>
</div>