@include('hamahang.Subjects.view_subject_modals.helper.subject_inline_js')
<table id="subjects_subjectType_Grid" class="table table-striped table-bordered dt-responsive nowrap display" style="width: 99%;">
    <thead>
    <tr>
        <th>ردیف</th>
        <th>عنوان</th>
        <th>تاریخ ویرایش</th>
    </tr>
    </thead>

</table>




