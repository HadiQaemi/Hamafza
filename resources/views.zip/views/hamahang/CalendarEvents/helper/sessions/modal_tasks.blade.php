<div class="modal fade" id="modal_tasks">
    <div class="modal-dialog modal-lg" role="dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">
                    <span> وظیفه </span>:
                    <span class="bg-warning"
                          style="padding:2px 10px; margin-right: 10px;"></span>
                </h4>
            </div><!-- end modal header -->
            <div class="modal-body">


            </div><!-- end body  -->
            <div class="modal-footer">
            </div><!-- end footer  -->
        </div><!-- end modal content -->
    </div><!-- end role  -->
</div><!