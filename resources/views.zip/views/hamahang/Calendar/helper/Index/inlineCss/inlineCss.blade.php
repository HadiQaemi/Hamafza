<style>
   .event_historical
    {

    }
   .event_vacation
   {

   }
   .even_event
   {


   }
   .even_session
   {

   }
   .even_invitation
   {

   }
   .even_invitation
   {

   }
   .even_reminder
   {

   }
    .share_event
    {

    }
    .calendar-main-setting div:nth-child(1)
    {
        margin: 5px;
        font-weight: 900px;
        font-size: 16px;
    }
</style>