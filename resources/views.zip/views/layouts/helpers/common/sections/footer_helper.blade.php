<footer class="" style="position: absolute;bottom: 0px;width: 100%">
    {!! menuGenerator(4, 'footer') !!}
</footer>


{{--
<footer class="navbar-fixed-bottom">
    {!! menuGenerator(4, 'footer') !!}
</footer>
--}}
