<footer class="navbar-fixed-bottom">
    <div class="footer-bottom ">
        <div class="row text-center">
            <ul class="nav nav-pills center-block">
                <li class=""><a href="#"> درباره ما </a><img src="img/seperator.png"></li>
                <li class=""><a href="http:\\www.hamafza.ir/ms">تماس با ما</a><img src="img/seperator.png"></li>
                <li class=""><a href="http:\\www.hamafza.ir/100">درگاه هم افزا </a><img src="img/seperator.png"></li>
                <li class=""><a href="http:\\www.hamafza.co"> فناوران مدیریت علم هم افزا </a></li>
            </ul>

        </div>
    </div>
    <!--/.footer-bottom-->
</footer>