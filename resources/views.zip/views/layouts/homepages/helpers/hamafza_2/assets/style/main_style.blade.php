<link rel="stylesheet" type="text/css" href="{{ URL::asset('theme/hamafza/index_2/css/bootstrap.css') }}"/>
<link rel="stylesheet" type="text/css" href="{{ URL::asset('theme/hamafza/index_2/css/content.css') }}"/>
<link rel="stylesheet" type="text/css" href="{{ URL::asset('theme/Content/css/font-awesome.min.css') }}"/>
<link rel="stylesheet" type="text/css" href="{{ URL::asset('theme/hamafza/index_2/css/font-awesome.min.css') }}"/>


