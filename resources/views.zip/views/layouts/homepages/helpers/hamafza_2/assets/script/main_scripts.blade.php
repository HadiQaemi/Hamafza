<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="{{URL::asset('theme/hamafza/index_2/js/dropdown.js')}}"></script>
<script src="{{URL::asset('theme/hamafza/index_2/js/collapse.js')}}"></script>
<script src="{{URL::asset('theme/hamafza/index_2/js/transition.js')}}"></script>
<script src="{{URL::asset('theme/hamafza/index_2/js/tooltip.js')}}"></script>
<script src="{{URL::asset('theme/hamafza/index_2/js/modal.js')}}"></script>
<script src="{{URL::asset('theme/hamafza/index_2/js/carousel.js')}}"></script>