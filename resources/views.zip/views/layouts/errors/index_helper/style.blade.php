<link rel="stylesheet" type="text/css" href="{{URL::asset('assets/Packages/bootstrap/css/bootstrap.css')}}"/>
<link rel="stylesheet" type="text/css" href="{{App::make('url')->to('/')}}/theme/Content/css/style.css"/>
<link rel="stylesheet" type="text/css" href="{{App::make('url')->to('/')}}/theme/Content/css/public.css"/>