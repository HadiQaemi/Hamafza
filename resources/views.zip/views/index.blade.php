@extends('layouts.index')
@section('content')
    @include('layouts.homepages.hamafza')
@stop